<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>High Quality products that Support your Health - Herball's Food</title>
    <meta name="Description" content="High Quality products that Support your Health use our natural products, we have the best natural products for your health">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <header class="Header ">
        <div class="Header-menuCart">
            <div class="icon phone">
                <span class="ic icon-phone"></span>
                <p>786-518-2903</p>        
            </div>
            <div  class="icon findUs">
                 <span class="ic icon-location"></span>
                <p>Find Us</p>         
            </div>
            <div class="icon cart">
                 <span class="ic icon-cart"></span>
                <p class="cantidad">0</p>           
            </div>
        </div>
        <div class="Header-menuMain wrap">
            <a href="index.php">
            <div class="logo">
                <img src="imagenes_herballsfood/logo_principal.png" alt="">
            </div>
            </a>
            <nav class="menu"> 
                <a href="about_us.php"><li>About Us</li></a>
                <a href="our_products.php"><li>Products</li></a>
                <a href="contact_us.php"><li>Contact Us</li></a>
            </nav>
        </div>
    </header>
    
