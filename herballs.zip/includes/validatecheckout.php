<?php 
include_once("conexion.php");
$fname=$_POST["fname"];
$lname=$_POST["lname"];
$email=$_POST["email"];
$tel=$_POST["tel"];
$adress1=$_POST["adress1"];
$adress2=$_POST["adress2"];
$zip=$_POST["zip"];
$subtotalx=$_POST["subtotalx"];
$totalx=$_POST["totalx"];
$cartx=$_POST["cartx"];


$prods=json_decode($cartx);


// SENDING EMAIL MODAFOCAS

// multiple recipients
$to  = $email;

// subject
$subject = 'Test Modafocas';

// message
$message = '
<html>
<head>
  <title>Hello '.$fname.'</title>
</head>
<body>
  <p>Here are the birthdays upcoming in August!</p>
  <table>'.
    for($x = 0;$x<count($prods->products);$x++ ){
    .'<tr><td>'.$prods->products[$x]->product).'</td></tr>'.
}.'
   
  </table>
</body>
</html>
';

// To send HTML mail, the Content-type header must be set
$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";

// Additional headers

$headers .= 'From: Herballs Food Sales <sales@herballsfood.com>' . "\r\n";
$headers .= 'Bcc: tic@highnutritionco.com' . "\r\n";

// Mail it
mail($to, $subject, $message, $headers);



exit();
?>